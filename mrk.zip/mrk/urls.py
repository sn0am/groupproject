from django.contrib import admin
from django.urls import path
from . import views
from django.conf.urls.static import static
from django.conf.urls import url
from django.conf import settings

urlpatterns = [

    path('aboutus/', views.aboutus, name="aboutus"),

    # task view URL paths
    path('tasks/', views.tasks, name="tasks"),                         # listing of all unclaimed tasks
    path('tasksearch/', views.tasks, name="tasksearch"),               # search box on task page handler
    path('advsearch/', views.advTaskSearch, name="advTaskSearch"),     # url path that loads the advSearch view and redirects to advsearch.html for searching tasks

    # task management URL paths
    path('addtask/', views.addtask, name="addtask"),                   # handler for "Create Task" button on tasks.html
    path('edit/<int:pk>/', views.edit, name="edit"),                   # handler for editing task details
    path('deletetask/<int:id>/', views.deletetask, name="deletetask"), # handler task delete selection
    path('claim/<int:id>/', views.claim, name="claim"),                # handler for claim task button in details.html
    path('release/<int:id>/', views.release, name="release"),          # handler for release task button in details.html
    path('complete/<int:id>/', views.complete, name="complete"),       # handler for complete task button in details.html
    path('pay/<int:id>/', views.pay, name="pay"),                      # handler for pay task button in details.html
    path('details/<str:pk>/', views.taskDetails, name="details"),      # Task Details Page: loads the taskDetails view and redirects to details.html

    # user management URL paths
    path('profile/<int:pk>/', views.userProfile, name="profile"),      # Profile Page: loads the userProfile view and redirects to profile.html/pk/
    path('register/', views.register, name="register"),                # Register Page: loads the register view and redirects to register.html
    path('login/', views.loginPage, name="login"),                     # Login Page: loads the loginPage view and redirects to login.html
    path('logout/', views.logoutUser, name="logout"),                  # Logout Page: loads the logoutUser view and logs out the user
    path('advusersearch/', views.advUserSearch, name="advUserSearch"), # Advanced User Search: loads the advUserSearch view and redirects to advusersearch.html
    path('proffilter/<int:pk>/', views.profile_cat_filter, name="proffilter"),# Advanced Profile Search: loads the profile_cat_filter view and allows task filtering on user profile via dropdown.
    path('users/', views.users, name="users"),                         # Users Page: loads the users view and redirects to users.html
    path('edituser/<int:pk>/', views.editSiteUser, name="editSiteUser"),# Edit User Page: loads the editSiteUser view and redirects to edituser.html/pk/ to edit specific user information
    path('find/<str:username>/', views.find_id, name="find"),          # Profile Link to Task Creator: Visible on task.html. Redirects to profile.html/username/ of the task creator.

    # test function path
    path('testfunc/', views.testFunc, name='testFunc'),                # serves no purpose

    # always last
    path('', views.home, name="home"),                                 # Home Page: redirects to homepage.html when no other address is entered.
]