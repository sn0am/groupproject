from django.forms import ModelForm
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Task
from .models import SiteUser
from django import forms



class CreateUserForm(UserCreationForm):
    # This form is called when user is registering for the website.
    # Form is shown on register.html

    class Meta:
        model = User
        fields = ['username', 'first_name', 'last_name', 'email', 'password1', 'password2']

class AddTaskForm(ModelForm):
    # This form is called when user is adding a task on the website.
    # Form is shown on addtask.html

    class Meta:
        model = Task
        fields = ['title', 'category', 'details', 'price']

class editForm(ModelForm):
    # This form is called when admin is editing a task on the website.
    # Form is shown on edit.html

    class Meta:
        model = Task
        fields = ['title', 'category', 'details', 'price']

class editUserForm(ModelForm):
    # This form is called when admin is editing a user that is registered on the website.
    # This form is also called when a registered user is trying to edit their own information.
    # This form is used in the editSiteUser view
    # Form is shown on edituser.html

    class Meta:
        model = User
        fields = []

class editSiteUserForm(ModelForm):
    # This form is called when admin is editing a user that is registered on the website.
    # This form is also called when a registered user is trying to edit their own information.
    # This form is used in the editSiteUser view
    # Form is shown on edituser.html

    class Meta:
        model = SiteUser

        fields = ['street_address',
                  'city',
                  'state_prov',
                  'postal_code',
                  'country',
                  'phone',
                  'suffix',
                  'email']

