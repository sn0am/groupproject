import django_filters
from .models import *
from django_filters import NumberFilter, CharFilter, DateFilter


class TaskFilterAdmin(django_filters.FilterSet):
    # This is a task filtering form
    # This form is shown when an admin clicks on the advanced search button on the tasks.html page
    # This form shows admin specific advanced search parameters not visible to regular users.

    title_name = CharFilter(field_name="title", lookup_expr='icontains')
    description_detail = CharFilter(field_name="details", lookup_expr='icontains')
    start_price = NumberFilter(field_name="price", lookup_expr='gte')
    ending_price = NumberFilter(field_name="price", lookup_expr='lte')
    beginning_date = DateFilter(field_name="date_created", lookup_expr='gte')
    ending_date = DateFilter(field_name="date_created", lookup_expr='lte')

    class Meta:
        model = Task
        fields = ['title_name','description_detail','status','category','creator','claimant','beginning_date','ending_date','start_price','ending_price']

class TaskFilter(django_filters.FilterSet):
    # This is a task filtering form
    # This form is shown when a regular registered user clicks on the advanced search button on the tasks.html page
    # This form shows regular search parameters not available on the standard search bar.
    # This form is only available to admins


    title_name = CharFilter(field_name="title", lookup_expr='icontains')
    description_detail = CharFilter(field_name="details", lookup_expr='icontains')
    start_price = NumberFilter(field_name="price", lookup_expr='gte')
    ending_price = NumberFilter(field_name="price", lookup_expr='lte')
    beginning_date = DateFilter(field_name="date_created", lookup_expr='gte')
    ending_date = DateFilter(field_name="date_created", lookup_expr='lte')
    class Meta:
        model = Task
        fields = ['title_name','description_detail','category','creator','beginning_date','ending_date','start_price','ending_price',]

class UserFilter(django_filters.FilterSet):
    # This is a user filtering form
    # This form is shown when an admin clicks on the advanced search button on the users.html page
    # This form is only available to admins

    user_name = CharFilter(field_name="username", lookup_expr='icontains')
    first_name = CharFilter(field_name="first_name", lookup_expr='icontains')
    last_name = CharFilter(field_name="last_name", lookup_expr='icontains')
    email = CharFilter(field_name="email", lookup_expr='icontains')
    beginning_date = DateFilter(field_name="date_joined", lookup_expr='gte')
    ending_date = DateFilter(field_name="date_joined", lookup_expr='lte')
    first_log = DateFilter(field_name="last_login", lookup_expr='gte')
    last_log = DateFilter(field_name="last_login", lookup_expr='lte')

    class Meta:
        model = User
        fields = ['user_name','first_name','last_name','email','beginning_date','ending_date','first_log','last_log']

class ProfileTaskFilter(django_filters.FilterSet):
    # This is a task filtering form
    # This form is shown when a user clicks on the advanced search button on the profile.html page
    # This form is used to search created or claimed task by a registered user

    title_name = CharFilter(field_name="title", lookup_expr='icontains')
    description_detail = CharFilter(field_name="details", lookup_expr='icontains')
    start_price = NumberFilter(field_name="price", lookup_expr='gte')
    ending_price = NumberFilter(field_name="price", lookup_expr='lte')
    beginning_date = DateFilter(field_name="date_created", lookup_expr='gte')
    ending_date = DateFilter(field_name="date_created", lookup_expr='lte')
    class Meta:
        model = Task
        fields = ['title_name','description_detail','category','status','creator','beginning_date','ending_date','start_price','ending_price',]

