# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from django.contrib.auth.models import User

class SiteUser(models.Model):
    # Database Model for SiteUser
    # Created in tandem with User model (which exists by default in Django) and has a 1-to-1 connection to it.
    # This is used to add additional information to created users.

    username = models.OneToOneField(User, on_delete=models.CASCADE, null=True)
    first_name = models.CharField(max_length=200, null=True, blank=True)
    last_name = models.CharField(max_length=200, null=True, blank=True)
    date_created = models.DateTimeField(auto_now_add=True)
    last_seen = models.CharField(max_length=200, null=True, blank=True)
    street_address = models.CharField(max_length=200, null=True, blank=True)
    city = models.CharField(max_length=200, null=True, blank=True)
    state_prov = models.CharField(max_length=200, null=True, blank=True)
    postal_code = models.CharField(max_length=200, null=True, blank=True)
    country = models.CharField(max_length=200, null=True, blank=True)
    phone = models.CharField(max_length=200, null=True, blank=True)
    suffix = models.CharField(max_length=200, null=True, blank=True)
    email = models.CharField(max_length=200, null=True, blank=True)

    def __str__(self):
        return str(self.username)

class Task(models.Model):
    # Database Model for Task
    # All created tasks have a Many-to-1 connection with the SiteUser Model.

    status_choices = [
        ('Available', 'Available'),
        ('Claimed', 'Claimed'),
        ('Completed', 'Completed'),
        ('Paid', 'Paid')]

    category_choices = [
        ('Code', 'Code'),
        ('Labor', 'Labor'),
        ('Design', 'Design'),
        ('Graphics', 'Graphics'),
        ('Transport', 'Transport'),
        ('Other', 'Other')]

    id = models.AutoField(primary_key=True)
    creator = models.ForeignKey(User, related_name='%(class)s_Creator', on_delete=models.CASCADE, null=True, blank=True)
    claimant = models.ForeignKey(User, related_name='%(class)s_Claimant', on_delete=models.SET_NULL, null=True, blank=True)
    date_created = models.DateTimeField(auto_now_add=True)
    price = models.DecimalField(max_digits=8, decimal_places=2)
    status = models.CharField(max_length=30 , choices=status_choices, null=False, default='Available')
    title = models.CharField(max_length=200, null=True)
    details = models.CharField(max_length=500, null=True)
    category = models.CharField(max_length=30 , choices=category_choices, null=True)
    image = models.ImageField(null=True, blank=True)

    def __str__(self):
        return str(self.title)

    @property
    def imageURL(self):
        try:
            url = self.image.url
        except:
            url = ''
        return url

