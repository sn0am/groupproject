from __future__ import unicode_literals
from datetime import datetime
from django.shortcuts import render, redirect
from django.http import HttpResponse, JsonResponse
from django.contrib import messages
from .forms import CreateUserForm
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .forms import AddTaskForm
from .models import Task
from .forms import editForm
from .forms import editUserForm
from .forms import editSiteUserForm
from .filters import TaskFilter, UserFilter
from .filters import TaskFilterAdmin
from .utils import *

def home(request):
    # This is called when user enters the base website url without a path.
    # Directs user to homepage.html.

    context = {}
    return render(request, 'store/homepage.html', context)


@login_required(login_url='login')
def aboutus(request):
    # This is called when user clicks on the about us button on the navbar.
    # Directs user to aboutus.html.
    # login is required

    context = {}
    return render(request, 'store/aboutus.html', context)

def loginPage(request):
    # This is called when user clicks on the get started button on the homepage, or their username in the navbar.
    # IF user is not currently logged in, Directs user to login.html.
    # Else if the user is logged in, Directs user to their profile if their username is clicked,
    # or the tasks page if the get started button is clicked.

    if request.user.is_authenticated:
        return redirect('profile')
    else:
        if request.method == 'POST':
            username = request.POST.get('username')
            password = request.POST.get('password')

            user = authenticate(request, username=username, password=password)

            if user is not None:
                login(request, user)
                print('debug views.py: logged in and attempting to redirect.')
                try:
                    siteUser = SiteUser.objects.get(username=user)
                    siteUser.last_seen = str(datetime.now())
                    siteUser.save()
                    print('updating last_seen')
                except:
                    print('Error. User might not be in SiteUser table.')
                return redirect('tasks')
            else:
                messages.info(request, 'Username OR password is incorrect')

        context = {}

        return render(request, 'store/login.html', context)

def register(request):
    # This is called when user clicks on the sign up button in the login page.
    # Registration form is called which takes the necessary information to create an account.
    # Entered information is checked for validity and the form is saved.
    # User is redirected to login page after successful registration.

    if request.user.is_authenticated:
        return redirect('profile')
    else:
        form = CreateUserForm()

        if request.method == 'POST':
            form = CreateUserForm(request.POST)
            if form.is_valid():
                form.save()
                user = form.cleaned_data.get('username')
                messages.success(request, 'Account was created for ' + user + '. Please log-in.')
                first_name = form.cleaned_data.get('first_name')
                last_name = form.cleaned_data.get('last_name')
                siteUser, created = SiteUser.objects.get_or_create(email=form.cleaned_data.get('email'),)
                userObj = User.objects.get(username=user)
                siteUser.username = userObj
                print('dev - views.register(..) - first_name: ', first_name, ', last_name:', last_name)
                siteUser.first_name = first_name
                siteUser.last_name = last_name

                siteUser.save()
                return redirect('login')

        context = {'form': form}

        return render(request, 'store/register.html', context)

@login_required(login_url='login')
def tasks(request):
    # This is used to display the information on the tasks page.
    # If some search criteria is entered in the search bar, available tasks matching that criteria are returned and showed on the task page.
    # Else, if no search is entered, all available tasks are shown.
    # login is required

    if request.method == "POST":
        tasksearch = request.POST.get('tasksearch', False)
        tasks = Task.objects.filter(title__contains=tasksearch, status='Available') | Task.objects.filter(
            details__contains=tasksearch, status='Available') | Task.objects.filter(category__contains=tasksearch, status='Available')
        context = {'tasksearch': tasksearch, 'tasks': tasks}
        return render(request, 'store/tasks.html', context)
    else:
        tasks = Task.objects.filter(status='Available')
        context = {'tasks': tasks}
        return render(request, 'store/tasks.html', context)

def logoutUser(request):
    # This is used to logout the currently logged in user when the logout button is pressed on the navbar.

    logout(request)

    return redirect('login')

@login_required(login_url='login')
def userProfile(request, pk):
    # This is the logic that will fetch data to display on a profile page.
    # profile.html is called to display the data
    # login is required

    #Prepare data to be passed to profile.html
    details = SiteUser.objects.get(id=pk)
    created_tasks = Task.objects.filter(creator=details.username)  #Retreive list of all created tasks based on profile user
    created_tasks_total = len(list(created_tasks))             #Calculate created task total number for UI display
    claimed_tasks = Task.objects.filter(claimant=details.username) #Reteive list of all tasks where profile user is claimant
    claimed_tasks_total = len(list(claimed_tasks))             #Calculate claimed task total number for UI display

    #Determine total earnings
    total_earnings = 0 #variable to update as claimed+paid tasks are iterated below
    for task in claimed_tasks:
        if task.status == 'Paid':
            total_earnings += task.price

    #Prepare context dictionary to be passed/accessed within profile.html
    context = {'details': details,
               'created_tasks':created_tasks,
               'created_tasks_total':created_tasks_total,
               'claimed_tasks':claimed_tasks,
               'claimed_tasks_total':claimed_tasks_total,
               'total_earnings':total_earnings,
               'filtered_tasks':created_tasks,
               'filter_choice':''
              }
    return render(request, 'store/profile.html', context)

@login_required(login_url='login')
def taskDetails(request, pk):
    # This is the logic that is used to display the details page of a created task.
    # details.html is called when the details button is clicked on a task.
    # login is required

    # id makes sure that we get the details for the requested task.
    task = Task.objects.get(id=pk)
    context = {'task':task}
    print('no error here')
    return render(request, 'store/details.html', context)


def testFunc(request, _task):
    # This is just a testing function, it serves no purpose!

    notifyClaimantSMS(request, _task)
    return JsonResponse('This is simply a test', safe=False)

@login_required(login_url='login')
def addtask(request):
    # This is the logic that is used to display the details page of a created task.
    # user is directed to tasks.html after the task has been created.
    # login is required.

    if request.user.is_authenticated:
        user = request.user
        form = AddTaskForm()

        if request.method == 'POST':
            form = AddTaskForm(request.POST)
            if form.is_valid():
                addtasks = form.save(commit=False)
                addtasks.creator = user
                addtasks.save()
                print(addtasks)
                return redirect('tasks')

        context = {'form': form}
        return render(request, 'store/addtask.html', context)

    else:

        context = {'form': form}
        return render(request, 'store/tasks.html', context)


@login_required(login_url='login')
def deletetask(request , id ):
    # This is the logic used when a task creator wants to delete their created task.
    # user is directed to tasks.html after the task has been deleted.
    # login and authentication is required

    if request.user.is_authenticated:
        Task.objects.get(pk = id).delete()
        return redirect('tasks')
    else:
        return redirect('tasks')

@login_required(login_url='login')
def claim(request, id):
    # This is the logic used when a user wants to claim a created task.
    # user is directed to tasks.html after the task has been claimed.
    # login and authentication is required

    task_to_claim = Task.objects.get(pk=id)
    task_to_claim.status = 'Claimed'
    task_to_claim.claimant = request.user
    task_to_claim.save()

    return redirect('tasks')

@login_required(login_url='login')
def release(request, id):
    # This is the logic used when a user wants to release a claimed task.
    # user is directed to their own profile.html after the task has been released.
    # login is required

    user = None
    release = Task.objects.get(pk = id)
    release.status = 'Available'
    release.claimant = user
    release.save()

    return redirect('profile', request.user.id)

@login_required(login_url='login')
def complete(request, id):
    # This is the logic used when a user wants to complete a claimed task.
    # user is directed to their own profile.html after the task has been completed.
    # login is required

    complete = Task.objects.get(pk = id)
    complete.status = "Completed"
    complete.save()
    notifyCreatorSMS(request, complete) # Task Creator is sent a notification that their posted task has been completed

    return redirect('profile', request.user.id)

@login_required(login_url='login')
def edit(request, pk):
    # This is the logic used when admin wants to edit a posted task.
    # admin is redirected to edit.html once they click on the edit button for a task.
    # admin is directed to their tasks.html after the task has been successfully edited.
    # login is required and being a superuser is required.

    if request.user.is_superuser:
        editTask = Task.objects.get(id=pk)
        form = editForm(instance=editTask)
        if request.method == 'POST':
            form = editForm(request.POST, instance=editTask)
            if form.is_valid():
                form.save()
            return redirect('tasks')
        context = {'form': form}
        return render(request, 'store/edit.html', context)
    else:
        return redirect('tasks')

@login_required(login_url='login')
def users(request):
    # This is the logic used when admin wants to look at or search for registered users.
    # The requested information is shown on users.html
    # if search criteria is entered in the search bar, users matching that criteria are shown.
    # else all registered users are shown.
    # login is required and being a superuser is required.
    # if user is not superuser, they will be redirected to tasks.html

    if request.user.is_superuser:
        if request.method == "POST":
            usersearch = request.POST.get('usersearch', False)
            users = User.objects.filter(username__contains=usersearch).exclude(is_superuser=True) | User.objects.filter(
                first_name__contains=usersearch).exclude(is_superuser=True) | User.objects.filter(
                last_name__contains=usersearch).exclude(is_superuser=True) | User.objects.filter(
                email__contains=usersearch).exclude(is_superuser=True)
            print(usersearch)
            context = {'usersearch': usersearch, 'users': users}
            return render(request, 'store/users.html', context)
        else:
            users = User.objects.all().exclude(is_superuser=True)
            context = {'users': users}
            return render(request, 'store/users.html', context)
    else:
        return redirect('tasks')


@login_required(login_url='login')
def editSiteUser(request, pk):
    # This is the logic used when admin wants to edit a users profile information, or if a user wants to edit their own information.
    # Clicking on edit takes requester to edituser.html/id/ where id is for the requested user.
    # Only the user with the requested id is shown for editing.
    # superuser login or authentication is required.

    if request.user.id == pk or request.user.is_superuser:
        userObject = User.objects.get(id=pk)
        userObj = SiteUser.objects.get(id=pk)
        user_form = editUserForm(instance=userObject)
        siteUser_form = editSiteUserForm(instance=userObj)
        #print(form.fields)
        if request.method == 'POST':
            user_form = editUserForm(request.POST, instance=userObject)
            siteUser_form = editSiteUserForm(request.POST, instance=userObj)
            #if form.is_valid():
            if all((user_form.is_valid(), siteUser_form.is_valid())):
                userprofile = user_form.save()
                siteuserprofile = siteUser_form.save(commit=False)
                siteuserprofile.username = userprofile
                siteuserprofile.save()
            else:
                print(user_form.errors)
                print(siteUser_form.errors)
            if request.user.is_superuser:
                return redirect('users')
            else:
                return redirect('profile', pk)
        context = {'user_form': user_form, 'siteUser_form': siteUser_form }
        return render(request, 'store/edituser.html', context)
    else:
        print('Views.editSiteUser(..) possible error')
        return redirect('profile')

@login_required(login_url='login')
def advTaskSearch(request):
    # This is the logic used for the advanced task search function on tasks.html
    # Clicking the Advanced Search will redirect user to advsearch.html
    # TaskFilterAdmin is shown if requesting user is admin.
    # else TaskFilter is shown if requesting user is a regular registered user.
    # Django-filters is used and the filters are stored and imported from filters.py
    # superuser login or authentication is required.

    tasks = Task.objects.all()  # get tasks from database

    if request.user.is_superuser:
        advTaskSearch = TaskFilterAdmin(request.GET, queryset=tasks)
        tasks = advTaskSearch.qs
        context = {'advTaskSearch': advTaskSearch, 'tasks': tasks}
        return render(request, 'store/advsearch.html', context)
    else:
        advTaskSearch = TaskFilter(request.GET, queryset=tasks)
        tasks = advTaskSearch.qs
        context = {'advTaskSearch': advTaskSearch, 'tasks': tasks}
        return render(request, 'store/advsearch.html', context)

@login_required(login_url='login')
def advUserSearch(request):
    # This is the logic used for the advanced user search function on users.html
    # Clicking Advanced Search will redirect user to advusersearch.html
    # UserFilter is shown if requesting user is admin.
    # else user is redirected to tasks.html
    # Django-filters is used and the filters are stored and imported from filters.py
    # superuser login is required.

    if request.user.is_superuser:
        users = User.objects.all().exclude(is_superuser=True)  # get tasks from database
        if request.user.is_superuser:
            advUserSearch = UserFilter(request.GET, queryset=users)
            users = advUserSearch.qs
            context = {'advUserSearch': advUserSearch, 'users': users}
            return render(request, 'store/advusersearch.html', context)
        else:
            return render(request, 'store/tasks.html')
    else:
        return render(request, 'store/tasks.html')

@login_required(login_url='login')
def pay(request, id):
    # This is the logic used when a user wants to pay for a completed task.
    # Visible as a button in task details.html after task has been compeleted.
    # user is directed to their own profile.html after the task has been paid.
    # login is required

    paid_task = Task.objects.get(pk=id)
    paid_task.status = 'Paid'
    paid_task.save()
    notifyClaimantSMS(request, paid_task)  # User that has completed the task is sent a notification that their work has been paid.

    return redirect('profile', request.user.id)



@login_required(login_url='login')
def profile_cat_filter(request, pk):
    # This is the function that is called through the user profile task filtering dropdown menu
    # The dropdown menu is used so the user can filter their created or claimed tasks by status
    # login is required

        details = SiteUser.objects.get(id=pk)
        print(details.username)
        filtered_tasks = []
        filter_choice = ''
        if request.method == "POST":
            selected_filter = request.POST.get('chgcat', False)
            print('Selected category filter:', selected_filter)
            if selected_filter == 'all_claimed':
                filter_choice = 'All Claimed '
                print('user wants to see all claimed in profile')
                filtered_tasks = Task.objects.filter(claimant=details.username)

            if selected_filter == 'inprogress_claimed':
                filter_choice = 'In Progress Claimed '
                print('user wants to see all in-progress claimed in profile')
                filtered_tasks = Task.objects.filter(claimant=details.username, status='Claimed')

            if selected_filter == 'paid_claimed':
                filter_choice = 'Paid Claimed '
                print('user wants to see all paid claimed in profile')
                filtered_tasks = Task.objects.filter(claimant=details.username, status='Paid')

            if selected_filter == 'completed_claimed':
                filter_choice = 'Completed Claimed '
                print('user wants to see all completed claimed in profile')
                filtered_tasks = Task.objects.filter(claimant=details.username, status='Completed')

            if selected_filter == 'all_created':
                filter_choice = 'All Created '
                print('user wants to see all created in profile')
                filtered_tasks = Task.objects.filter(creator=details.username)

            if selected_filter == 'inprogress_created':
                filter_choice = 'In Progress Created '
                print('user wants to see all in-progress created in profile')
                filtered_tasks = Task.objects.filter(creator=details.username, status='Claimed')

            if selected_filter == 'completed_created':
                filter_choice = 'Completed Created '
                print('user wants to see all completed created in profile')
                filtered_tasks = Task.objects.filter(creator=details.username, status='Completed')

            if selected_filter == 'paid_created':
                filter_choice = 'Paid Created '
                print('user wants to see all paid created in profile')
                filtered_tasks = Task.objects.filter(creator=details.username, status='Paid')

            print(selected_filter)

            created_tasks = Task.objects.filter(creator=details.username)  # Retrieve list of all created tasks based on profile user
            created_tasks_total = len(list(created_tasks))  # Calculate created task total number for UI display
            claimed_tasks = Task.objects.filter(claimant=details.username)  # Retrieve list of all tasks where profile user is claimant
            claimed_tasks_total = len(list(claimed_tasks))  # Calculate claimed task total number for UI display

            # Determine total earnings
            total_earnings = 0  # variable to update as claimed+paid tasks are iterated below
            for task in claimed_tasks:
                if task.status == 'Paid':
                    total_earnings += task.price

            # Prepare context dictionary to be passed/accessed within profile.html
            context = {'details': details,
                       'created_tasks': created_tasks,
                       'created_tasks_total': created_tasks_total,
                       'claimed_tasks': claimed_tasks,
                       'claimed_tasks_total': claimed_tasks_total,
                       'total_earnings': total_earnings,
                       'filtered_tasks': filtered_tasks,
                       'filter_choice': filter_choice
                       }
            return render(request, 'store/profile.html', context)
        else:
            return render(request, 'store/profile.html')


@login_required(login_url='login')
def find_id(request, username):
    # This logic shows the username of the task creator in the tasks.html page
    # Clicking on the username takes requester to the profile.html/id/ of the clicked username
    # login is required

    if request.user.is_authenticated:
        userObj = User.objects.get(username=username)
        return redirect('profile', userObj.id)
    else:
        return redirect('login')