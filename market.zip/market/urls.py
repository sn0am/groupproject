from django.contrib import admin
from django.urls import path
from . import views
from django.conf.urls.static import static
from django.conf.urls import url
from django.conf import settings
from django.contrib.auth import views as auth_views
from .views import deletetask
from .views import claim
from .views import release
from .views import complete
from .views import deleteuser

urlpatterns = [
    path('tasks/', views.tasks, name="tasks"),
    path('profile/', views.proftasks, name="proftasks"),
    path('supprofile/<int:pk>/', views.supproftasks, name="supproftasks"),
    path('register/', views.register, name="register"),
    path('login/', views.loginPage, name="login"),
    path('logout/', views.logoutUser, name="logout"),
    path('profile/', views.userProfile, name="profile"),
    path('details/<str:pk>/', views.taskDetails, name="details"),
    path('aboutus/', views.aboutus, name="aboutus"),
    path('users/', views.users, name="users"),
    #  path('users/', views.showusers, name="showusers"),
    path('addtask/', views.addtask, name="addtask"),
    path('edit/<int:pk>/', views.edit, name="edit"),
    path('edituser/<int:pk>/', views.edituser, name="edituser"),
    # path('editpassword/<int:pk>/', views.editpassword, name="editpassword"),
    path('deletetask/<int:id>/', deletetask),
    path('deleteuser/<int:id>/', deleteuser),
    path('claim/<int:id>/<str:status>/', claim),
    path('release/<int:id>/<str:status>/', release),
    path('complete/<int:id>/<str:status>/', complete),
    path('testFunc/', views.testFunc),
    path('', views.home, name="home"),
]