from django.contrib import admin
from django.urls import path
from . import views
from django.conf.urls.static import static
from django.conf.urls import url
from django.conf import settings
# from .views import deletetask
# from .views import claim
# from .views import release
# from .views import complete
# from .views import proftasks
# from .views import edit

urlpatterns = [
    path('tasks/', views.tasks, name="tasks"),
    path('tasklist/', views.tasks_list, name="tasklist"),
    path('register/', views.register, name="register"),
    path('login/', views.loginPage, name="login"),
    path('logout/', views.logoutUser, name="logout"),
    path('profile/', views.userProfile, name="profile"),
    path('details/<str:pk>/', views.taskDetails, name="details"),
    path('aboutus/', views.aboutus, name="aboutus"),
    path('addtask/', views.addtask, name="addtask"),

    #5-1-21
    #path('profile/', views.proftasks, name="proftasks"),
    path('edit/<int:pk>/', views.edit, name="edit"),
    path('deletetask/<int:id>/', views.deletetask, name="deletetask"),
    path('claim/<int:id>/', views.claim, name="claim"),
    path('release/<int:id>/<str:status>/', views.release),
    path('complete/<int:id>/<str:status>/', views.complete),
    path('update/<str:pk>/<str:status>/', views.update_task_status, name="update"),

    #5-3-21
    #path('testfunc/', views.testFunc, name='addtask'),
    path('tasksearch/', views.tasksearch, name="tasksearch"),
    path('advsearch/', views.advTaskSearch, name="advTaskSearch"),
    path('profilesearch/', views.profiletasksearch, name="profilesearch"),
    path('advprofilesearch/', views.advProfileTaskSearch, name="advprofilesearch"),
    path('usersearch/', views.usersearch, name="usersearch"),
    path('advusersearch/', views.advUserSearch, name="advUserSearch"),
    path('pay/<int:id>/', views.pay, name="pay"),
    path('searchpayments/', views.paymentsearch, name="paymentsearch"),
    path('advsearchpayments/', views.advPaymentSearch, name="advpaymentsearch"),
    path('taskpayments/', views.proftaskpayments, name="taskpayments"),

    #5-5-21
    path('proffilter/', views.profile_cat_filter, name="proffilter"),
    path('users/', views.users, name="users"),
    path('supprofile/<int:pk>/', views.supproftasks, name="supproftasks"),
    path('edituser/<int:pk>/', views.edituser, name="edituser"),
    path('deleteuser/<int:id>/', views.deleteuser, name="deleteuser"),

    # 5-6-21
    path('editprofile/<int:pk>/', views.editprofile, name="editprofile"),

    #always last
    path('', views.home, name="home"),
]