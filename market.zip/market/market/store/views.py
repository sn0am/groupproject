from __future__ import unicode_literals
from datetime import datetime
import json
from django.shortcuts import render, redirect
from django.http import HttpResponse, JsonResponse
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages

from .models import *
from .forms import CreateUserForm
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from .forms import AddTaskForm
from.models import SiteUser
from django.contrib.auth.forms import SetPasswordForm
from django.contrib.auth.models import User
from .filters import TaskFilter, UserFilter
from .filters import TaskFilterAdmin
from .filters import ProfileTaskFilter

#5-1-21
from django.views.generic import UpdateView
from .models import Task
from .forms import editForm

#5-4-21
from .forms import editForm
from .forms import editUserForm
from .forms import editProfileForm
from django.contrib.auth.forms import SetPasswordForm
from django.contrib.auth.models import User
from .filters import TaskFilter, UserFilter
from .filters import TaskFilterAdmin
from .filters import ProfileTaskFilter
from .filters import PaymentFilter

def home(request):

    context = {}
    return render(request, 'store/homepage.html', context)


def aboutus(request):

    context = {}
    return render(request, 'store/aboutus.html', context)

def loginPage(request):
    if request.user.is_authenticated:
        return redirect('profile')
    else:
        if request.method == 'POST':
            username = request.POST.get('username')
            password = request.POST.get('password')

            user = authenticate(request, username=username, password=password)

            if user is not None:
                login(request, user)
                print('debug views.py: logged in and attempting to redirect.')
                try:
                    siteUser = SiteUser.objects.get(username=user)
                    siteUser.last_seen = str(datetime.now())
                    siteUser.save()
                    print('updating last_seen')
                except:
                    print('Error. User might not be in SiteUser table.')
                return redirect('tasks')
            else:
                messages.info(request, 'Username OR password is incorrect')

        context = {}
        return render(request, 'store/login.html', context)

def register(request):
    if request.user.is_authenticated:
        return redirect('profile')
    else:
        form = CreateUserForm()

        if request.method == 'POST':
            form = CreateUserForm(request.POST)
            if form.is_valid():
                form.save()
                user = form.cleaned_data.get('username')
                messages.success(request, 'Account was created for ' + user + '. Please log-in.')
                first_name = form.cleaned_data.get('first_name')
                last_name = form.cleaned_data.get('last_name')
                siteUser, created = SiteUser.objects.get_or_create(email=form.cleaned_data.get('email'),)
                userObj = User.objects.get(username=user)
                siteUser.username = userObj
                print('dev - views.register(..) - first_name: ', first_name, ', last_name:', last_name)
                siteUser.first_name = first_name
                siteUser.last_name = last_name

                siteUser.save()
                return redirect('login')

        context = {'form': form}
        return render(request, 'store/register.html', context)

@login_required(login_url='login')
def tasks(request):

    #tasks = Task.objects.all() #get tasks from database
    tasks = Task.objects.filter(status='Available')
    context = {'tasks': tasks}
    return render(request, 'store/tasks.html', context)

#OLD tasks function
@login_required(login_url='login')
def tasks_list(request):

    tasks = Task.objects.all() #get tasks from database
    context = {'tasks': tasks}
    return render(request, 'store/tasklist.html', context)

# @login_required(login_url='login')
# def profileTasks(request):
#
#     tasks = Task.objects.all() #get tasks from database
#     context = {'tasks': tasks}
#     return render(request, 'store/profile.html', context)

def logoutUser(request):
    logout(request)
    return redirect('login')

@login_required(login_url='login')
def userProfile(request):

    #Prepare data to be passed to profile.html
    created_tasks = Task.objects.filter(creator=request.user)  #Retreive list of all created tasks based on profile user
    created_tasks_total = len(list(created_tasks))             #Calculate created task total number for UI display
    claimed_tasks = Task.objects.filter(claimant=request.user) #Reteive list of all tasks where profile user is claimant
    claimed_tasks_total = len(list(claimed_tasks))             #Calculate claimed task total number for UI display

    #Determine total earnings
    total_earnings = 0 #variable to update as claimed+paid tasks are iterated below
    for task in claimed_tasks:
        if task.status == 'Paid':
            total_earnings += task.price

    #Prepare context dictionary to be passed/accessed within profile.html
    context = {'created_tasks':created_tasks,
               'created_tasks_total':created_tasks_total,
               'claimed_tasks':claimed_tasks,
               'claimed_tasks_total':claimed_tasks_total,
               'total_earnings':total_earnings,
               'filtered_tasks':created_tasks,
               'filter_choice':''
              }
    return render(request, 'store/profile.html', context)

@login_required(login_url='login')
def taskDetails(request, pk):
    task = Task.objects.get(id=pk)
    context = {'task':task}
    print('no error here')
    return render(request, 'store/details.html', context)

def testFunc(request):
    user = User.objects.get(id=3)
    print('dev - Views.py.testFunc(..): user.username ', user.username)
    user.set_password('testtesttest2')
    user.save()
    return JsonResponse('This is simply a test', safe=False)

def addtask(request):

    if request.user.is_authenticated:
        user = request.user
        form = AddTaskForm()

        if request.method == 'POST':
            form = AddTaskForm(request.POST)
            if form.is_valid():
                addtasks = form.save(commit=False)
                addtasks.creator = user
                addtasks.save()
                print(addtasks)
                return redirect('tasks')

        context = {'form': form}
        return render(request, 'store/addtask.html', context)

    else:

        context = {'form': form}
        return render(request, 'store/tasks.html', context)

@login_required(login_url='login')
def deletetask(request , id ):
    if request.user.is_authenticated:
        Task.objects.get(pk = id).delete()
        return redirect('tasks')
    else:
        return redirect('tasks')

def claim(request, id):
    task_to_claim = Task.objects.get(pk=id)
    task_to_claim.status = 'Claimed'
    task_to_claim.claimant = request.user
    task_to_claim.save()

    #context = {}
    return redirect('tasks')

def release(request , id , status):
    if request.user.is_authenticated:
        user = None
    release = Task.objects.get(pk = id)
    release.status = status
    release.claimed = user
    release.save()
    return redirect('profile')

def complete(request , id , status):
    if request.user.is_authenticated:
        user = request.user
    complete = Task.objects.get(pk = id)
    complete.status = status
    complete.claimed = user
    complete.save()


    return redirect('profile')

@login_required(login_url='login')
def edit(request, pk):
            if request.user.is_superuser:
                editTask = Task.objects.get(id=pk)
                form = editForm(instance=editTask)
                if request.method == 'POST':
                    form = editForm(request.POST, instance=editTask)
                    if form.is_valid():
                        form.save()
                    return redirect('tasks')
                context = {'form': form}
                return render(request, 'store/edit.html', context)
            else:
                return redirect('tasks')

@login_required(login_url='login')
def users(request):
    # if request.user.is_authenticated:
    # print('request.user.is_authenticated:', request.user.is_authenticated, '. Currently logged in user: ', request.user)
    # else:
    # print('request.user.is_authenticated:', request.user.is_authenticated)
    # send user to login page.
    if request.user.is_superuser:
        users = User.objects.all().exclude(is_superuser=True)
        context = {'users': users}
        return render(request, 'store/users.html', context)

    else:
        return redirect('tasks')


@login_required(login_url='login')
def edituser(request, pk):
    if request.user.is_superuser:
        userEdit = User.objects.get(id=pk)
        form = editUserForm(instance=userEdit)
        if request.method == 'POST':
            form = editUserForm(request.POST, instance=userEdit)
            # userEdit = authenticate(request, username=username, password=password)
            if form.is_valid():
                form.save()
            return redirect('users')
        context = {'form': form}
        return render(request, 'store/edituser.html', context)
    else:
        return redirect('users')


# @login_required(login_url='login')
# def editpassword(request, pk):
#
#        if request.user.is_superuser:
#            passedit = User.objects.get(id=pk)
#            if request.method == "POST" :
#                form = SetPasswordForm(request.POST, user=passedit)
#                if form.is_valid():
#                    form.save()
#                    update_session_auth_hash(request, form.user)
#                    return redirect('users')
#                else:
#                    fm = SetPasswordForm(user=pk)
#                return render(request, 'editpassword', {'form': fm})
#            else:
#                return redirect('users')
#        else:
#            return redirect('tasks')


@login_required(login_url='login')
def deleteuser(request, id):
    if request.user.is_superuser:
        User.objects.get(pk=id).delete()
        return redirect('users')
    else:
        return redirect('users')


@login_required(login_url='login')
def supproftasks(request, pk):
    if request.user.is_superuser:
        fetch_user = User.objects.get(id=pk)
        supproftasks = Task.objects.all()   # get tasks from database
        context = {'supproftasks': supproftasks, 'fetch_user': fetch_user}
        return render(request, 'store/supprofile.html', context)
    else:
        return redirect('tasks')


def tasksearch(request):
    if request.method == "POST":
        tasksearch = request.POST.get('tasksearch', False)
        tasks = Task.objects.filter(title__contains=tasksearch) | Task.objects.filter(
            details__contains=tasksearch) | Task.objects.filter(category__contains=tasksearch)
        print(tasksearch)
        context = {'tasksearch': tasksearch, 'tasks': tasks}
        return render(request, 'store/tasksearch.html', context)
    else:
        return render(request, 'store/tasksearch.html')


def advTaskSearch(request):
    tasks = Task.objects.all()  # get tasks from database

    if request.user.is_superuser:
        advTaskSearch = TaskFilterAdmin(request.GET, queryset=tasks)
        tasks = advTaskSearch.qs
        context = {'advTaskSearch': advTaskSearch, 'tasks': tasks}
        return render(request, 'store/advsearch.html', context)
    else:
        advTaskSearch = TaskFilter(request.GET, queryset=tasks)
        tasks = advTaskSearch.qs
        context = {'advTaskSearch': advTaskSearch, 'tasks': tasks}
        return render(request, 'store/advsearch.html', context)


@login_required(login_url='login')
def profiletasksearch(request):
        if request.method == "POST":
            profilesearch = request.POST.get('profilesearch', False)
            print(profilesearch)
            tasks = Task.objects.filter(title__contains=profilesearch) | Task.objects.filter(
                details__contains=profilesearch) | Task.objects.filter(category__contains=profilesearch)
            print(profilesearch)
            context = {'profilesearch': profilesearch, 'tasks': tasks}
            return render(request, 'store/profilesearch.html', context)
        else:
            return render(request, 'store/profilesearch.html')


@login_required(login_url='login')
def advProfileTaskSearch(request):
    if request.user.is_authenticated:
        tasks = Task.objects.all()  # get tasks from database
        advProfileTaskSearch = ProfileTaskFilter(request.GET, queryset=tasks)
        tasks = advProfileTaskSearch.qs
        context = {'advProfileTaskSearch': advProfileTaskSearch, 'tasks': tasks}
    return render(request, 'store/advprofilesearch.html', context)


@login_required(login_url='login')
def usersearch(request):
    if request.user.is_superuser:
        if request.method == "POST":
            usersearch = request.POST.get('usersearch', False)
            users = User.objects.filter(username__contains=usersearch).exclude(is_superuser=True) | User.objects.filter(
                first_name__contains=usersearch).exclude(is_superuser=True) | User.objects.filter(
                last_name__contains=usersearch).exclude(is_superuser=True) | User.objects.filter(
                email__contains=usersearch).exclude(is_superuser=True)
            print(usersearch)
            context = {'usersearch': usersearch, 'users': users}
            return render(request, 'store/usersearch.html', context)
        else:
            return render(request, 'store/usersearch.html')
    else:
        return render(request, 'store/tasks.html')


@login_required(login_url='login')
def advUserSearch(request):
    if request.user.is_superuser:
        users = User.objects.all().exclude(is_superuser=True)  # get tasks from database
        if request.user.is_superuser:
            advUserSearch = UserFilter(request.GET, queryset=users)
            tasks = advUserSearch.qs
            context = {'advUserSearch': advUserSearch, 'users': users}
            return render(request, 'store/advusersearch.html', context)
        else:
            return render(request, 'store/tasks.html')
    else:
        return render(request, 'store/tasks.html')

@login_required(login_url='login')
def pay(request, id):

    paid_task = Task.objects.get(pk=id)
    paid_task.status = 'Paid'
    paid_task.save()

    return redirect('profile')

@login_required(login_url='login')
def proftaskpayments(request):

    tasks = Task.objects.all()  # get tasks from database
    context = {'tasks': tasks}
    return render(request, 'store/taskpayments.html', context)


@login_required(login_url='login')
def paymentsearch(request):
        if request.method == "POST":
            paymentsearch = request.POST.get('paymentsearch', False)
            tasks = Task.objects.filter(title__contains=paymentsearch) | Task.objects.filter(
                details__contains=paymentsearch) | Task.objects.filter(category__contains=paymentsearch)
            print(paymentsearch)
            context = {'paymentsearch': paymentsearch, 'tasks': tasks}
            return render(request, 'store/searchpayments.html', context)
        else:
            return render(request, 'store/profilesearch.html')

@login_required(login_url='login')
def advPaymentSearch(request):

    if request.user.is_authenticated:
        tasks = Task.objects.all()  # get tasks from database
        advPaymentSearch = PaymentFilter(request.GET, queryset=tasks)
        tasks = advPaymentSearch.qs
        context = {'advPaymentSearch': advPaymentSearch, 'tasks': tasks}
    return render(request, 'store/advsearchpayments.html', context)

#5-5-21
@login_required(login_url='login')
def update_task_status(request, pk, status):

    print('dev - Views.update_task_status(..): Status received:', status, ', task.id(pk):', pk)
    task_to_update = Task.objects.get(pk=pk)
    if task_to_update.claimant == request.user or task_to_update.creator == requst.user:
        pass
    else:
        return JsonResponse('Unauthorized', safe=False)
    task_to_update.status = status
    #complete.claimed = user
    task_to_update.save()

    #Open to manipulation by any logged in user with url

    return redirect('profile')

@login_required(login_url='login')
def profile_cat_filter(request):
        filtered_tasks = []
        filter_choice = ''
        if request.method == "POST":
            selected_filter = request.POST.get('chgcat', False)
            print('Selected category filter:', selected_filter)
            if selected_filter == 'all_claimed':
                filter_choice = 'All Claimed '
                print('user wants to see all claimed in profile')
                filtered_tasks = Task.objects.filter(claimant=request.user)

            if selected_filter == 'inprogress_claimed':
                filter_choice = 'In Progress Claimed '
                print('user wants to see all in-progress claimed in profile')
                filtered_tasks = Task.objects.filter(claimant=request.user, status='Claimed')

            if selected_filter == 'paid_claimed':
                filter_choice = 'Paid Claimed '
                print('user wants to see all paid claimed in profile')
                filtered_tasks = Task.objects.filter(claimant=request.user, status='Paid')

            if selected_filter == 'completed_claimed':
                filter_choice = 'Completed Claimed '
                print('user wants to see all completed claimed in profile')
                filtered_tasks = Task.objects.filter(claimant=request.user, status='Completed')

            if selected_filter == 'all_created':
                filter_choice = 'All Created '
                print('user wants to see all created in profile')
                filtered_tasks = Task.objects.filter(creator=request.user)

            if selected_filter == 'inprogress_created':
                filter_choice = 'In Progress Created '
                print('user wants to see all in-progress created in profile')
                filtered_tasks = Task.objects.filter(creator=request.user, status='Claimed')

            if selected_filter == 'completed_created':
                filter_choice = 'Completed Created '
                print('user wants to see all completed created in profile')
                filtered_tasks = Task.objects.filter(creator=request.user, status='Completed')

            if selected_filter == 'paid_created':
                filter_choice = 'Paid Created '
                print('user wants to see all paid created in profile')
                filtered_tasks = Task.objects.filter(creator=request.user, status='Paid')

            print(selected_filter)

            created_tasks = Task.objects.filter(creator=request.user)  # Retreive list of all created tasks based on profile user
            created_tasks_total = len(list(created_tasks))  # Calculate created task total number for UI display
            claimed_tasks = Task.objects.filter(claimant=request.user)  # Reteive list of all tasks where profile user is claimant
            claimed_tasks_total = len(list(claimed_tasks))  # Calculate claimed task total number for UI display

            # Determine total earnings
            total_earnings = 0  # variable to update as claimed+paid tasks are iterated below
            for task in claimed_tasks:
                if task.status == 'Paid':
                    total_earnings += task.price

            # Prepare context dictionary to be passed/accessed within profile.html
            context = {'created_tasks': created_tasks,
                       'created_tasks_total': created_tasks_total,
                       'claimed_tasks': claimed_tasks,
                       'claimed_tasks_total': claimed_tasks_total,
                       'total_earnings': total_earnings,
                       'filtered_tasks': filtered_tasks,
                       'filter_choice': filter_choice
                       }
            return render(request, 'store/profile.html', context)
        else:
            return render(request, 'store/profile.html')

# User can edit some fields from their own profile!
@login_required(login_url='login')
def editprofile(request, pk):
    if request.user.is_authenticated:
        profileEdit = User.objects.get(id = pk)
        form = editProfileForm(instance=profileEdit)
        if request.method == 'POST':
            form = editProfileForm(request.POST, instance=profileEdit)
            # userEdit = authenticate(request, username=username, password=password)
            if form.is_valid():
                form.save()
            return redirect('profile')
        context = {'form': form}
        return render(request, 'store/editprofile.html', context)
    else:
        return redirect('tasks')
