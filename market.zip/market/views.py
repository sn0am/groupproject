from __future__ import unicode_literals
import datetime
import json
from django.shortcuts import render, redirect
from django.http import HttpResponse, JsonResponse
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.views.generic import UpdateView
from .models import *
from .models import Task
from .forms import CreateUserForm
from django.contrib.auth import authenticate, login, logout, update_session_auth_hash
from django.contrib.auth.decorators import login_required
from .forms import AddTaskForm
from .forms import editForm
from .forms import editUserForm
from django.contrib.auth.forms import SetPasswordForm
from django.contrib.auth.models import User

def home(request):

    context = {}
    return render(request, 'store/homepage.html', context)


def aboutus(request):

    context = {}
    return render(request, 'store/aboutus.html', context)

def loginPage(request):
    if request.user.is_authenticated:
        return redirect('profile')
    else:
        if request.method == 'POST':
            username = request.POST.get('username')
            password = request.POST.get('password')

            user = authenticate(request, username=username, password=password)

            if user is not None:
                login(request, user)
                print('debug views.py: logged in and attempting to redirect.')
                return redirect('tasks')
            else:
                messages.info(request, 'Username OR password is incorrect')

        context = {}
        return render(request, 'store/login.html', context)

def register(request):
    if request.user.is_authenticated:
        return redirect('profile')
    else:
        form = CreateUserForm()

        if request.method == 'POST':
            form = CreateUserForm(request.POST)
            if form.is_valid():
                form.save()
                user = form.cleaned_data.get('username')
                messages.success(request, 'Account was created for ' + user + '. Please log-in.')
                return redirect('login')

        context = {'form': form}
        return render(request, 'store/register.html', context)

@login_required(login_url='login')
def tasks(request):
    #if request.user.is_authenticated:
        #print('request.user.is_authenticated:', request.user.is_authenticated, '. Currently logged in user: ', request.user)
    #else:
        #print('request.user.is_authenticated:', request.user.is_authenticated)
        # send user to login page.

    tasks = Task.objects.all() #get tasks from database
    context = {'tasks': tasks}
    return render(request, 'store/tasks.html', context)

def logoutUser(request):
    logout(request)
    return redirect('login')

@login_required(login_url='login')
def userProfile(request):
    context = {}
    return render(request, 'store/profile.html', context)

@login_required(login_url='login')
def taskDetails(request, pk):
    task = Task.objects.get(id=pk)
    context = {'task': task}
    return render(request, 'store/details.html', context)

def testFunc(request):
    user = User.objects.get(id=7)
    print('dev - Views.py.testFunc(..): user.username ', user.username)
    user.set_password('testtesttest2')
    user.save()
    return JsonResponse('This is simply a test', safe=False)

def addtask(request):

    if request.user.is_authenticated:
        user = request.user
        form = AddTaskForm()

        if request.method == 'POST':
            form = AddTaskForm(request.POST)
            if form.is_valid():
                addtasks = form.save(commit=False)
                addtasks.creator = user
                addtasks.save()
                print(addtasks)
                return redirect('tasks')

        context = {'form': form}
        return render(request, 'store/addtask.html', context)

    else:

        context = {'form': form}
        return render(request, 'store/tasks.html', context)

@login_required(login_url='login')
def deletetask(request , id ):
    if request.user.is_superuser:
        Task.objects.get(pk = id).delete()
        return redirect('tasks')
    else:
        return redirect('tasks')

def claim(request , id , status):
    if request.user.is_authenticated:
        user = request.user
    claim = Task.objects.get(pk = id)
    claim.status = status
    claim.claimed = user
    claim.save()

    return redirect('tasks')

def release(request , id , status):
    if request.user.is_authenticated:
        user = request.user
    release = Task.objects.get(pk = id)
    release.status = status
    release.claimed = user
    release.save()
    return redirect('profile')

def complete(request , id , status):
    if request.user.is_authenticated:
        user = request.user
    complete = Task.objects.get(pk = id)
    complete.status = status
    complete.claimed = user
    complete.save()


    return redirect('profile')

@login_required(login_url='login')
def proftasks(request):
    #if request.user.is_authenticated:
        #print('request.user.is_authenticated:', request.user.is_authenticated, '. Currently logged in user: ', request.user)
    #else:
        #print('request.user.is_authenticated:', request.user.is_authenticated)
        # send user to login page.

    proftasks = Task.objects.all() #get tasks from database
    context = {'proftasks': proftasks}
    return render(request, 'store/profile.html', context)

@login_required(login_url='login')
def edit(request, pk):
            if request.user.is_superuser:
                editTask = Task.objects.get(id=pk)
                form = editForm(instance=editTask)
                if request.method == 'POST':
                    form = editForm(request.POST, instance=editTask)
                    if form.is_valid():
                        form.save()
                    return redirect('tasks')
                context = {'form': form}
                return render(request, 'store/edit.html', context)
            else:
                return redirect('tasks')

@login_required(login_url='login')
def users(request):
    #if request.user.is_authenticated:
        #print('request.user.is_authenticated:', request.user.is_authenticated, '. Currently logged in user: ', request.user)
    #else:
        #print('request.user.is_authenticated:', request.user.is_authenticated)
        # send user to login page.
    if request.user.is_superuser:
        users = User.objects.all().exclude(is_superuser=True)
        context = {'users': users}
        return render(request, 'store/users.html', context)

    else:
        return redirect('tasks')


@login_required(login_url='login')
def edituser(request, pk):
            if request.user.is_superuser:
                userEdit= User.objects.get(id=pk)
                form = editUserForm(instance=userEdit)
                if request.method == 'POST':
                    form = editUserForm(request.POST, instance=userEdit)
                    #userEdit = authenticate(request, username=username, password=password)
                    if form.is_valid():
                        form.save()
                    return redirect('users')
                context = {'form': form}
                return render(request, 'store/edituser.html', context)
            else:
                return redirect('users')

# @login_required(login_url='login')
# def editpassword(request, pk):
#
#        if request.user.is_superuser:
#            passedit = User.objects.get(id=pk)
#            if request.method == "POST" :
#                form = SetPasswordForm(request.POST, user=passedit)
#                if form.is_valid():
#                    form.save()
#                    update_session_auth_hash(request, form.user)
#                    return redirect('users')
#                else:
#                    fm = SetPasswordForm(user=pk)
#                return render(request, 'editpassword', {'form': fm})
#            else:
#                return redirect('users')
#        else:
#            return redirect('tasks')



@login_required(login_url='login')
def deleteuser(request , id):
    if request.user.is_superuser:
        User.objects.get(pk = id).delete()
        return redirect('users')
    else:
        return redirect('users')


def supproftasks(request, pk):

    if request.user.is_superuser:
        fetch_user = User.objects.get(id=pk)
        supproftasks = Task.objects.filter(creator=fetch_user) | Task.objects.filter(claimed=fetch_user) #get tasks from database
        context = {'supproftasks':supproftasks,'fetch_user': fetch_user}
        return render(request, 'store/supprofile.html', context)
    else:
        return redirect('tasks')


